import React, { Component } from 'react';
import Header from './Header';
import Personas from './Persona/Personas';

export default class App extends Component {

    constructor() {
        super();

        this.state = {
            title: 'Persona'
        };
    }

    render() {
        return (
            <div>
                <Header title={this.state.title} />
                <div className="mt-5">
                    <Personas />
                </div>
            </div>
        );
    }
}