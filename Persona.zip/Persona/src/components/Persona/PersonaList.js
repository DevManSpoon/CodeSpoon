import React from 'react';
import PropTypes from 'prop-types';
import PersonaCard from './PersonaCard';

const getPersonas = (personas) => {
    return (
        <div className="card-deck">
            {
                personas.map(persona => <PersonaCard key={persona.id} persona={persona} />)
            }
        </div>
    );
};

const PersonaList = (props) => (
    <div>
        {getPersonas(props.personas)}
    </div>
);

PersonaList.defaultProps = {
    personas: []
};

PersonaList.propTypes = {
    personas: PropTypes.array
};

export default PersonaList;