import React from 'react';
import PropTypes from 'prop-types';
import StarRating from '../StarRating';

const PersonaCard = (props) => (
    <div className="persona-card">
        <div className="persona-card card">
            <img className="card-img-top" src={props.persona.imageUrl} alt="" />
            <div className="card-body">
                <h4 className="card-title">{props.persona.title}</h4>
                <h6 className="card-subtitle mb-2 text-muted">{props.persona.subtitle}</h6>
                <p className="text-justify" style={{fontSize: '14px'}}>{props.persona.description}</p>
            </div>
            <div className="card-footer">
                <div className="clearfix">
                    <div className="float-left mt-1">
                        <StarRating rating={props.persona.rating} />
                    </div>
                    <div className="card-footer-badge float-right badge badge-primary badge-pill">{props.persona.rating}</div>
                </div>
            </div>
        </div>
    </div>
);

PersonaCard.defaultProps = {
    persona: {}
};

PersonaCard.propTypes = {
    persona: PropTypes.object
};

export default PersonaCard;