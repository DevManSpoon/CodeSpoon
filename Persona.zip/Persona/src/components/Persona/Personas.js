import React, { Component } from 'react';
import PersonaList from './PersonaList';
import PersonaService from '../../services/PersonaService';

export default class Personas extends Component {

    constructor() {
        super();

        this.state = {
            personas: []
        };
    }

    componentDidMount() {
        this.setState(() => ({ personas: PersonaService.getPersonas() }));
    }

    render() {
        return (
            <div className="container-fluid" style={{marginLeft: '-15px'}}>
                <div className="d-flex flex-row">                    
                    <div className="col-sm-12">
                        <PersonaList personas={this.state.personas} />
                    </div>
                </div>
            </div>
        );
    }
}