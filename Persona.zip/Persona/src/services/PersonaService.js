import personas from './personas.json';

export default class PersonaService {
    static getPersonas() {
        return personas ? personas : [];
    }
}