# Persona

React application that displays personas for UX development and ideation.